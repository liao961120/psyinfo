import numpy as np, matplotlib.pyplot as plt
data=np.loadtxt('exp_subj0.txt')
plt.close('all'); plt.plot(data,'.')
plt.legend(['COND','CORR','RT']); plt.axis([0,600,-2,4])
plt.figure(); plt.plot(data[:,1],'ro-',data[:,2],'b*'); plt.grid()
group=[]; c=['r','g','b']
for i in range(3):
  idx=(data[:,0]==i); group.append(data[idx,:])
plt.figure(); plt.hold(True)
for i in range(3):
  plt.hist(group[i][:,2],bins=10,color=c[i],alpha=0.5)