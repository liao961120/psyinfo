import numpy as np, matplotlib.pyplot as plt
data=np.loadtxt('exp_subj0.txt')
data=data[data[:,2]>0,:]
group=[]; means=[]; stds=[]; c=['r','g','b']
for i in range(3):
  idx=(data[:,0]==i); group.append(data[idx,:])
  means.append(np.mean(group[i][:,2]))
  stds.append(np.std(group[i][:,2]))
plt.close('all');
plt.bar(range(3),means,yerr=stds,color=c,ecolor='k')
#http://matplotlib.org/examples/api/barchart_demo.html